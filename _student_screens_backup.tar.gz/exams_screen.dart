import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:course_users/widgets/paginated_list_view.dart';

/// Exams Screen - View all exams
class ExamsScreen extends ConsumerWidget {
  const ExamsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final supabase = Supabase.instance.client;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Exams'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: PaginatedListView<Map<String, dynamic>>(
        fetcher: (page, pageSize) async {
          final data = await supabase
              .from('exams')
              .select('*, classes(*), programs(*)')
              .order('exam_date', ascending: true)
              .range(page * pageSize, page * pageSize + pageSize - 1);
          return List<Map<String, dynamic>>.from(data);
        },
        skeleton: (context) => const SkeletonListPage(itemCount: 8),
        empty: (context, _) => const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.quiz_rounded, size: 64, color: Colors.grey),
              SizedBox(height: 16),
              Text('No exams scheduled',
                  style: TextStyle(fontSize: 18, color: Colors.grey)),
            ],
          ),
        ),
        itemBuilder: (context, exam, index) {
          final examDate = exam['exam_date'] != null
              ? DateTime.parse(exam['exam_date'])
              : null;
          final isUpcoming = examDate?.isAfter(DateTime.now()) ?? false;

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isUpcoming
                              ? Colors.grey.shade300
                              : Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          Icons.quiz_rounded,
                          color: isUpcoming ? Colors.black87 : Colors.black87,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              exam['name'] ?? 'Untitled Exam',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              exam['subject'] ?? 'General',
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getStatusColor(exam['status']),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          exam['status']?.toString().toUpperCase() ??
                              'SCHEDULED',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _ExamInfoChip(Icons.calendar_today,
                          _formatDate(exam['exam_date'])),
                      const SizedBox(width: 8),
                      _ExamInfoChip(Icons.access_time,
                          '${exam['duration_minutes'] ?? 60} min'),
                      const SizedBox(width: 8),
                      _ExamInfoChip(Icons.stars,
                          '${exam['total_marks'] ?? 100} marks'),
                    ],
                  ),
                ],
              ),
            ),
          ).animate().fadeIn(delay: (100 * index).ms, duration: 400.ms);
        },
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status) {
      case 'scheduled':
        return Colors.black87;
      case 'completed':
        return Colors.black87;
      case 'cancelled':
        return Colors.red;
      case 'in_progress':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'No date';
    try {
      final dt = DateTime.parse(date.toString());
      return '${dt.day}/${dt.month}/${dt.year}';
    } catch (e) {
      return 'Invalid date';
    }
  }
}

/// Results Screen - Detailed exam results
class ResultsScreen extends ConsumerWidget {
  const ResultsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Results'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: PaginatedListView<Map<String, dynamic>>(
        fetcher: (page, pageSize) async {
          final data = await supabase
              .from('exam_results')
              .select('*')
              .eq('student_id', userId ?? '')
              .order('exam_date', ascending: false)
              .range(page * pageSize, page * pageSize + pageSize - 1);
          return List<Map<String, dynamic>>.from(data);
        },
        skeleton: (context) => const SkeletonListPage(itemCount: 8),
        empty: (context, _) => const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.assessment_rounded, size: 64, color: Colors.grey),
              SizedBox(height: 16),
              Text('No results available',
                  style: TextStyle(fontSize: 18, color: Colors.grey)),
            ],
          ),
        ),
        itemBuilder: (context, result, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          result['exam_name'] ?? 'Exam',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Text(
                        '${(result['percentage'] as num? ?? 0).toStringAsFixed(1)}%',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color:
                              (result['percentage'] as num? ?? 0) >= 75
                                  ? Colors.black87
                                  : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    result['subject'] ?? 'General',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _ExamInfoChip(Icons.score,
                          '${result['score']}/${result['max_score']}'),
                      const SizedBox(width: 8),
                      _ExamInfoChip(Icons.grade, result['grade'] ?? '-'),
                      const SizedBox(width: 8),
                      _ExamInfoChip(Icons.calendar_today,
                          _formatDate(result['exam_date'])),
                    ],
                  ),
                  if (result['comments'] != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        result['comments'],
                        style: const TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'No date';
    try {
      final dt = DateTime.parse(date.toString());
      return '${dt.day}/${dt.month}/${dt.year}';
    } catch (e) {
      return 'Invalid';
    }
  }
}

/// Certificates Screen - View and download certificates
class CertificatesScreen extends ConsumerWidget {
  const CertificatesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Certificates'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: PaginatedListView<Map<String, dynamic>>(
        fetcher: (page, pageSize) async {
          final data = await supabase
              .from('certificates')
              .select('*')
              .eq('student_id', userId ?? '')
              .eq('status', 'issued')
              .order('issue_date', ascending: false)
              .range(page * pageSize, page * pageSize + pageSize - 1);
          return List<Map<String, dynamic>>.from(data);
        },
        skeleton: (context) => const SkeletonListPage(itemCount: 8),
        empty: (context, _) => const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.card_membership_rounded,
                  size: 64, color: Colors.grey),
              SizedBox(height: 16),
              Text('No certificates yet',
                  style: TextStyle(fontSize: 18, color: Colors.grey)),
              SizedBox(height: 8),
              Text(
                'Complete courses to earn certificates',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ),
        itemBuilder: (context, cert, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: InkWell(
              onTap: () => _showCertificateDetail(context, cert),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.amber.shade400,
                            Colors.amber.shade700
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.card_membership,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            cert['certificate_type']?.toString().toUpperCase() ??
                                'CERTIFICATE',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey.shade600,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            cert['course_name'] ?? 'Course Certificate',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Issued: ${_formatDate(cert['issue_date'])}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              ),
            ),
          ).animate().fadeIn(delay: (100 * index).ms, duration: 400.ms);
        },
      ),
    );
  }

  void _showCertificateDetail(BuildContext context, Map<String, dynamic> cert) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.amber.shade400, Colors.amber.shade700],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(
                Icons.card_membership,
                color: Colors.white,
                size: 64,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              cert['certificate_type']?.toString().toUpperCase() ??
                  'CERTIFICATE',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              cert['course_name'] ?? 'Course Certificate',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            _ExamDetailRow(
                label: 'Certificate No',
                value: cert['certificate_number'] ?? '-'),
            _ExamDetailRow(
                label: 'Issue Date', value: _formatDate(cert['issue_date'])),
            if (cert['level_achieved'] != null)
              _ExamDetailRow(label: 'Level', value: cert['level_achieved']),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                // Download logic
              },
              icon: const Icon(Icons.download),
              label: const Text('Download Certificate'),
              style: FilledButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'N/A';
    try {
      final dt = DateTime.parse(date.toString());
      return '${dt.day}/${dt.month}/${dt.year}';
    } catch (e) {
      return 'Invalid';
    }
  }
}

// Helper Widgets
class _ExamInfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ExamInfoChip(this.icon, this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.grey.shade700),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade700)),
        ],
      ),
    );
  }
}

class _ExamDetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _ExamDetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade600)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
