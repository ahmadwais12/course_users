import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:course_users/models/attendance.dart';
import 'package:course_users/widgets/paginated_list_view.dart';
import 'package:course_users/providers/student_providers.dart';

class AttendanceScreenRealtime extends ConsumerStatefulWidget {
  const AttendanceScreenRealtime({super.key});

  @override
  ConsumerState<AttendanceScreenRealtime> createState() =>
      _AttendanceScreenRealtimeState();
}

class _AttendanceScreenRealtimeState
    extends ConsumerState<AttendanceScreenRealtime> {
  String selectedMonth = 'All';

  @override
  Widget build(BuildContext context) {
    final attendanceAsync = ref.watch(attendanceStreamProvider);

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Attendance Overview',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: attendanceAsync.when(
              data: (attendanceList) {
                if (attendanceList.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.event_busy_outlined,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No attendance records',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  );
                }

                final totalDays = attendanceList.length;
                final presentDays = attendanceList
                    .where((a) => a.status == AttendanceStatus.present)
                    .length;
                final attendancePercentage =
                    totalDays > 0 ? (presentDays / totalDays * 100) : 0.0;

                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(
                      color: _getAttendanceColor(attendancePercentage)
                          .withValues(alpha: 0.1),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          children: [
                            Icon(
                              Icons.pie_chart_outline,
                              size: 64,
                              color: _getAttendanceColor(attendancePercentage),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              '${attendancePercentage.toStringAsFixed(1)}%',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: _getAttendanceColor(
                                      attendancePercentage,
                                    ),
                                  ),
                            ),
                            Text(
                              'Overall Attendance',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _buildStatColumn(
                                  'Present',
                                  presentDays,
                                  Colors.black87,
                                ),
                                _buildStatColumn(
                                  'Absent',
                                  totalDays - presentDays,
                                  Colors.red,
                                ),
                                _buildStatColumn(
                                  'Total Days',
                                  totalDays,
                                  Colors.black87,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Recent Records',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    ...attendanceList.take(10).map(
                          (record) => Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: _getStatusBackgroundColor(
                                    record.status,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  _getStatusIcon(record.status),
                                  color: _getStatusForegroundColor(
                                    record.status,
                                  ),
                                ),
                              ),
                              title: Text(_formatDate(record.date)),
                              subtitle: Text(
                                '${record.classId} | ${record.notes ?? 'No notes'}',
                              ),
                              trailing: Chip(
                                label: Text(
                                  _formatStatus(record.status),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                                backgroundColor: _getStatusForegroundColor(
                                  record.status,
                                ),
                              ),
                            ),
                          ),
                        ),
                  ],
                );
              },
              loading: () => const SkeletonListPage(itemCount: 8),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
                    const SizedBox(height: 16),
                    Text('Error: $error'),
                    ElevatedButton.icon(
                      onPressed: () => ref.invalidate(attendanceStreamProvider),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getAttendanceColor(double percentage) {
    if (percentage < 50) return Colors.red;
    if (percentage < 75) return Colors.orange;
    if (percentage < 90) return Colors.black87;
    return Colors.black87;
  }

  Color _getStatusBackgroundColor(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return Colors.grey.shade300;
      case AttendanceStatus.absent:
        return Colors.red.shade100;
      case AttendanceStatus.late:
      case AttendanceStatus.leave:
        return Colors.orange.shade100;
    }
  }

  Color _getStatusForegroundColor(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return Colors.grey.shade800;
      case AttendanceStatus.absent:
        return Colors.red.shade700;
      case AttendanceStatus.late:
      case AttendanceStatus.leave:
        return Colors.orange.shade700;
    }
  }

  IconData _getStatusIcon(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return Icons.check_circle;
      case AttendanceStatus.absent:
        return Icons.cancel;
      case AttendanceStatus.late:
        return Icons.access_time;
      case AttendanceStatus.leave:
        return Icons.event_busy;
    }
  }

  String _formatStatus(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return 'Present';
      case AttendanceStatus.absent:
        return 'Absent';
      case AttendanceStatus.late:
        return 'Late';
      case AttendanceStatus.leave:
        return 'Leave';
    }
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }

  Widget _buildStatColumn(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: color,
              ),
        ),
        Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
      ],
    );
  }
}
