import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:course_users/widgets/paginated_list_view.dart';
import 'package:course_users/providers/student_providers.dart';

class AssignmentsScreenRealtime extends ConsumerStatefulWidget {
  const AssignmentsScreenRealtime({super.key});

  @override
  ConsumerState<AssignmentsScreenRealtime> createState() =>
      _AssignmentsScreenRealtimeState();
}

class _AssignmentsScreenRealtimeState
    extends ConsumerState<AssignmentsScreenRealtime> {
  String searchQuery = '';
  String filterStatus = 'All';

  @override
  Widget build(BuildContext context) {
    final assignmentsAsync = ref.watch(assignmentsStreamProvider);

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search assignments...',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              onChanged: (value) => setState(() => searchQuery = value),
            ),
          ),
          Expanded(
            child: assignmentsAsync.when(
              data: (assignments) {
                var filtered = assignments.where((a) {
                  final title = a['title']?.toString().toLowerCase() ?? '';
                  final matchesSearch =
                      title.contains(searchQuery.toLowerCase());
                  final matchesFilter =
                      filterStatus == 'All' || a['status'] == filterStatus;
                  return matchesSearch && matchesFilter;
                }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.assignment_outlined,
                            size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        Text('No assignments found',
                            style: TextStyle(
                                fontSize: 18, color: Colors.grey[600])),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final assignment = filtered[index];

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: _getStatusColor(assignment['status'])
                              .withValues(alpha: 0.1),
                          child: Icon(
                            _getStatusIcon(assignment['status']),
                            color: _getStatusColor(assignment['status']),
                          ),
                        ),
                        title:
                            Text(assignment['title']?.toString() ?? 'Untitled'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                '${assignment['subject']} • ${assignment['class']}'),
                            Text('Due: ${_formatDate(assignment['due_date'])}'),
                          ],
                        ),
                        trailing: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getStatusColor(assignment['status'])
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            assignment['status']?.toString() ?? 'Active',
                            style: TextStyle(
                              color: _getStatusColor(assignment['status']),
                              fontWeight: FontWeight.bold,
                              fontSize: 10,
                            ),
                          ),
                        ),
                        onTap: () => _showDetails(assignment),
                      ),
                    );
                  },
                );
              },
              loading: () => const SkeletonListPage(itemCount: 8),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
                    const SizedBox(height: 16),
                    Text('Error: $error'),
                    ElevatedButton.icon(
                      onPressed: () =>
                          ref.invalidate(assignmentsStreamProvider),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(dynamic status) {
    switch (status.toString().toLowerCase()) {
      case 'active':
        return Colors.black87;
      case 'submitted':
        return Colors.black87;
      case 'graded':
        return Colors.purple;
      case 'overdue':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(dynamic status) {
    switch (status.toString().toLowerCase()) {
      case 'active':
        return Icons.schedule;
      case 'submitted':
        return Icons.done_all;
      case 'graded':
        return Icons.grade;
      case 'overdue':
        return Icons.warning;
      default:
        return Icons.help_outline;
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'Not set';
    DateTime dt;
    if (date is String) {
      dt = DateTime.parse(date);
    } else if (date is DateTime) {
      dt = date;
    } else {
      return 'Not set';
    }
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  void _showDetails(Map<String, dynamic> assignment) {
    showModalBottomSheet(
      context: context,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                assignment['title']?.toString() ?? 'Untitled',
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              _buildDetailRow(
                  'Subject', assignment['subject']?.toString() ?? 'N/A'),
              _buildDetailRow(
                  'Class', assignment['class']?.toString() ?? 'N/A'),
              _buildDetailRow('Due Date', _formatDate(assignment['due_date'])),
              _buildDetailRow(
                  'Status', assignment['status']?.toString() ?? 'Active'),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Submit assignment feature')),
                  );
                },
                icon: const Icon(Icons.upload_file),
                label: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          SizedBox(
              width: 100,
              child: Text('$label:',
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
