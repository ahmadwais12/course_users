import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:course_users/components/skeleton_widgets.dart';

/// Academic History Screen - Full academic transcript
class AcademicHistoryScreen extends ConsumerWidget {
  const AcademicHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Academic History'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: FutureBuilder(
        future: Future.wait([
          supabase
              .from('students')
              .select('*')
              .eq('profile_id', userId ?? '')
              .single(),
          supabase
              .from('student_grades')
              .select('*')
              .eq('student_id', userId ?? '')
              .order('exam_date', ascending: false),
          supabase
              .from('certificates')
              .select('*')
              .eq('student_id', userId ?? '')
              .eq('status', 'issued'),
        ]),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const SkeletonDetailPage();
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error loading data'));
          }

          final results = snapshot.data as List;
          final student = results[0] as Map<String, dynamic>?;
          final grades = results[1] as List? ?? [];
          final certificates = results[2] as List? ?? [];

          // Calculate statistics
          final totalCourses = grades.map((g) => g['subject']).toSet().length;
          final avgGrade = grades.isEmpty
              ? 0.0
              : grades.fold<double>(
                    0,
                    (sum, g) => sum + (g['percentage'] as num? ?? 0).toDouble(),
                  ) /
                  grades.length;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Student Info Card
                _StudentInfoCard(
                  student: student,
                  totalCourses: totalCourses,
                  avgGrade: avgGrade,
                  certificates: certificates.length,
                ).animate().fadeIn(duration: 600.ms),
                const SizedBox(height: 24),

                // Timeline
                const Text(
                  'Academic Timeline',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),

                _TimelineSection(
                  title: 'Current Semester',
                  grades: grades.where((g) {
                    if (g['exam_date'] == null) return false;
                    try {
                      final date = DateTime.parse(g['exam_date']);
                      return date.isAfter(
                          DateTime.now().subtract(const Duration(days: 180)));
                    } catch (e) {
                      return false;
                    }
                  }).toList(),
                ).animate().fadeIn(delay: 200.ms, duration: 600.ms),
                const SizedBox(height: 16),

                _TimelineSection(
                  title: 'Previous Semester',
                  grades: grades.where((g) {
                    if (g['exam_date'] == null) return false;
                    try {
                      final date = DateTime.parse(g['exam_date']);
                      return date.isBefore(DateTime.now()
                              .subtract(const Duration(days: 180))) &&
                          date.isAfter(DateTime.now()
                              .subtract(const Duration(days: 365)));
                    } catch (e) {
                      return false;
                    }
                  }).toList(),
                ).animate().fadeIn(delay: 400.ms, duration: 600.ms),

                if (certificates.isNotEmpty) ...[
                  const SizedBox(height: 24),
                  const Text(
                    'Certificates Earned',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  ...certificates
                      .map((cert) => _CertificateMiniCard(cert: cert)),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Student Profile Screen
class StudentProfileScreen extends ConsumerStatefulWidget {
  const StudentProfileScreen({super.key});

  @override
  ConsumerState<StudentProfileScreen> createState() =>
      _StudentProfileScreenState();
}

class _StudentProfileScreenState extends ConsumerState<StudentProfileScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _emergencyController = TextEditingController();
  final _bioController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _emergencyController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final user = Supabase.instance.client.auth.currentUser;
    final metadata = user?.userMetadata ?? {};

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _loadProfileData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data ?? {};
          _nameController.text =
              data['full_name'] ?? metadata['full_name'] ?? '';
          _phoneController.text = data['phone'] ?? '';
          _addressController.text = data['address'] ?? '';
          _emergencyController.text = data['emergency_contact'] ?? '';
          _bioController.text = data['bio'] ?? '';

          final name =
              _nameController.text.isNotEmpty ? _nameController.text : 'User';
          final email = user?.email ?? data['email'] ?? 'N/A';
          final role = data['role']?.toString().toUpperCase() ??
              (metadata['role']?.toString().toUpperCase() ?? 'STUDENT');
          final studentCode = data['student_code'] ?? 'N/A';
          final joined = _formatDate(data['created_at']);
          final status = data['status']?.toString().toUpperCase() ?? 'ACTIVE';
          final gender = data['gender']?.toString().toUpperCase() ??
              metadata['gender']?.toString().toUpperCase() ??
              'N/A';
          final dob = data['date_of_birth'] != null
              ? _formatDate(data['date_of_birth'])
              : 'N/A';
          final nationality =
              data['nationality'] ?? metadata['nationality'] ?? 'N/A';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: theme.colorScheme.primaryContainer,
                        child: Text(
                          name.isNotEmpty ? name[0].toUpperCase() : 'U',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: theme.colorScheme.onPrimaryContainer,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(name,
                          style: theme.textTheme.headlineSmall
                              ?.copyWith(fontWeight: FontWeight.bold)),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color:
                              theme.colorScheme.primary.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(role,
                            style: TextStyle(
                                fontSize: 12,
                                color: theme.colorScheme.primary,
                                fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                Text('Personal Information',
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _InfoTile(
                    icon: Icons.person,
                    label: 'Full Name',
                    child: _buildEditableField(_nameController)),
                _InfoTile(
                    icon: Icons.phone,
                    label: 'Phone',
                    child: _buildEditableField(_phoneController,
                        keyboardType: TextInputType.phone)),
                _InfoTile(
                    icon: Icons.location_on,
                    label: 'Address',
                    child:
                        _buildEditableField(_addressController, maxLines: 2)),
                _InfoTile(
                    icon: Icons.emergency,
                    label: 'Emergency Contact',
                    child: _buildEditableField(_emergencyController,
                        keyboardType: TextInputType.phone)),
                _InfoTile(
                    icon: Icons.info,
                    label: 'Bio',
                    child: _buildEditableField(_bioController, maxLines: 3)),
                const SizedBox(height: 24),
                Text('Account Information',
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _InfoTile(icon: Icons.email, label: 'Email', value: email),
                _InfoTile(
                    icon: Icons.badge, label: 'Student ID', value: studentCode),
                _InfoTile(
                    icon: Icons.calendar_today, label: 'Joined', value: joined),
                _InfoTile(icon: Icons.circle, label: 'Status', value: status),
                const SizedBox(height: 24),
                Text('Additional Details',
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _InfoTile(icon: Icons.wc, label: 'Gender', value: gender),
                _InfoTile(icon: Icons.cake, label: 'Date of Birth', value: dob),
                _InfoTile(
                    icon: Icons.flag, label: 'Nationality', value: nationality),
                _InfoTile(
                    icon: Icons.phone_android,
                    label: 'Auth Phone',
                    value: user?.phone ?? 'N/A'),
                const SizedBox(height: 32),
                FilledButton.icon(
                  onPressed: _isLoading ? null : _updateProfile,
                  icon: _isLoading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.save),
                  label: Text(_isLoading ? 'Saving...' : 'Save Changes'),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size(double.infinity, 52),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildEditableField(TextEditingController controller,
      {TextInputType? keyboardType, int maxLines = 1}) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  Future<void> _updateProfile() async {
    setState(() => _isLoading = true);
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      await supabase.from('profiles').update({
        'full_name': _nameController.text,
        'phone': _phoneController.text,
        'address': _addressController.text,
        'emergency_contact': _emergencyController.text,
        'bio': _bioController.text,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', userId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Profile updated successfully'),
              backgroundColor: Colors.black87),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<Map<String, dynamic>?> _loadProfileData() async {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return null;
    try {
      return await supabase.from('profiles').select().eq('id', userId).single();
    } catch (e) {
      return null;
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'N/A';
    try {
      return DateFormat('MMM dd, yyyy').format(DateTime.parse(date));
    } catch (e) {
      return 'Invalid';
    }
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  final Widget? child;

  const _InfoTile(
      {required this.icon, required this.label, this.value, this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 18, color: theme.colorScheme.primary),
          ),
          const SizedBox(width: 12),
          ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 140),
              child: Text(label,
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(fontWeight: FontWeight.w600))),
          Expanded(
            child: child ??
                Text(value ?? 'N/A',
                    style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface
                            .withValues(alpha: 0.7))),
          ),
        ],
      ),
    );
  }
}

/// Placement Test Screen
class PlacementTestScreen extends ConsumerStatefulWidget {
  const PlacementTestScreen({super.key});

  @override
  ConsumerState<PlacementTestScreen> createState() =>
      _PlacementTestScreenState();
}

class _PlacementTestScreenState extends ConsumerState<PlacementTestScreen> {
  int _currentQuestion = 0;
  final Map<int, String> _answers = {};
  bool _isSubmitted = false;

  List<Map<String, dynamic>> _questions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  Future<void> _loadQuestions() async {
    final supabase = Supabase.instance.client;
    try {
      final data = await supabase
          .from('placement_questions')
          .select()
          .order('display_order');
      if (mounted) {
        setState(() {
          _questions = List<Map<String, dynamic>>.from(data);
          _isLoading = false;
        });
      }
    } catch (_) {
      try {
        final data = await supabase.from('assessment_questions').select('*');
        if (mounted) {
          setState(() {
            _questions = List<Map<String, dynamic>>.from(data);
            _isLoading = false;
          });
        }
      } catch (_) {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  void _selectAnswer(String answer) {
    setState(() {
      _answers[_currentQuestion] = answer;
    });
  }

  void _nextQuestion() {
    if (_currentQuestion < _questions.length - 1) {
      setState(() => _currentQuestion++);
    } else {
      setState(() => _isSubmitted = true);
      _savePlacementTestResult();
    }
  }

  Future<void> _savePlacementTestResult() async {
    int correctCount = 0;
    for (int i = 0; i < _questions.length; i++) {
      final selectedAnswer = _answers[i];
      final correctAnswer = _questions[i]['correct_answer'];
      if (selectedAnswer != null && selectedAnswer == correctAnswer) {
        correctCount++;
      }
    }
    try {
      await Supabase.instance.client.from('test_results').insert({
        'test_type': 'placement',
        'score': correctCount,
        'total': _questions.length,
        'answers': _answers,
        'user_id': Supabase.instance.client.auth.currentUser?.id,
      });
    } catch (_) {}
  }

  void _previousQuestion() {
    if (_currentQuestion > 0) {
      setState(() => _currentQuestion--);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Placement Test'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _isSubmitted
              ? _buildResults()
              : _buildTest(),
    );
  }

  Widget _buildTest() {
    final question = _questions[_currentQuestion];
    final progress = (_currentQuestion + 1) / _questions.length;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress Bar
          LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation(Colors.black87),
            minHeight: 8,
          ),
          const SizedBox(height: 8),
          Text(
            'Question ${_currentQuestion + 1} of ${_questions.length}',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
          ),
          const SizedBox(height: 32),

          // Question
          Text(
            question['question'],
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ).animate().fadeIn(duration: 400.ms),
          const SizedBox(height: 24),

          // Options
          ...(question['options'] as List).map((option) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _OptionTile(
                  label: option,
                  isSelected: _answers[_currentQuestion] == option,
                  onTap: () => _selectAnswer(option),
                ),
              )),

          const Spacer(),

          // Navigation Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (_currentQuestion > 0)
                OutlinedButton.icon(
                  onPressed: _previousQuestion,
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Previous'),
                )
              else
                const SizedBox.shrink(),
              FilledButton.icon(
                onPressed:
                    _answers[_currentQuestion] == null ? null : _nextQuestion,
                icon: Icon(_currentQuestion == _questions.length - 1
                    ? Icons.check
                    : Icons.arrow_forward),
                label: Text(_currentQuestion == _questions.length - 1
                    ? 'Submit'
                    : 'Next'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResults() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.check_circle,
            color: Colors.black87,
            size: 80,
          ).animate().scale(
              begin: const Offset(0, 0),
              end: const Offset(1, 1),
              duration: 600.ms),
          const SizedBox(height: 24),
          const Text(
            'Test Completed!',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text(
            'Your recommended level: Intermediate',
            style: TextStyle(fontSize: 16, color: Colors.grey.shade700),
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                const Icon(Icons.school, color: Colors.black87, size: 40),
                const SizedBox(height: 12),
                const Text(
                  'Based on your answers, we recommend:',
                  style: TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 8),
                Text(
                  'B1 Intermediate English',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
              ],
            ),
          ).animate().fadeIn(delay: 400.ms, duration: 600.ms),
          const SizedBox(height: 32),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.home),
            label: const Text('Back to Dashboard'),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            ),
          ),
        ],
      ),
    );
  }
}

// Helper Widgets
class _StudentInfoCard extends StatelessWidget {
  final Map<String, dynamic>? student;
  final int totalCourses;
  final double avgGrade;
  final int certificates;

  const _StudentInfoCard({
    required this.student,
    required this.totalCourses,
    required this.avgGrade,
    required this.certificates,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.grey.shade700, Colors.grey.shade900],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: Text(
                  (student?['full_name']?[0] ?? 'S').toUpperCase(),
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      student?['full_name'] ?? 'Student',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      student?['student_code'] ?? 'ID: N/A',
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _StatItem(label: 'Courses', value: totalCourses.toString()),
              _StatItem(
                  label: 'Avg Grade', value: '${avgGrade.toStringAsFixed(1)}%'),
              _StatItem(label: 'Certificates', value: certificates.toString()),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  const _StatItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _TimelineSection extends StatelessWidget {
  final String title;
  final List grades;

  const _TimelineSection({required this.title, required this.grades});

  @override
  Widget build(BuildContext context) {
    if (grades.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('No records for this period',
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...grades.map((g) => _GradeTimelineItem(grade: g)),
      ],
    );
  }
}

class _GradeTimelineItem extends StatelessWidget {
  final Map<String, dynamic> grade;
  const _GradeTimelineItem({required this.grade});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 40,
            decoration: BoxDecoration(
              color: (grade['percentage'] as num? ?? 0) >= 75
                  ? Colors.black87
                  : Colors.orange,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  grade['subject'] ?? 'Subject',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                Text(
                  _formatDate(grade['exam_date']),
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
          Text(
            '${(grade['percentage'] as num? ?? 0).toStringAsFixed(0)}%',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: (grade['percentage'] as num? ?? 0) >= 75
                  ? Colors.black87
                  : Colors.orange,
            ),
          ),
        ],
      ),
    );
  }

  static String _formatDate(dynamic date) {
    if (date == null) return 'No date';
    try {
      return DateFormat('MMM dd, yyyy').format(DateTime.parse(date));
    } catch (e) {
      return 'Invalid';
    }
  }
}

class _CertificateMiniCard extends StatelessWidget {
  final Map<String, dynamic> cert;
  const _CertificateMiniCard({required this.cert});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.amber.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.amber.shade200),
      ),
      child: Row(
        children: [
          Icon(Icons.card_membership, color: Colors.amber.shade700),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              cert['course_name'] ?? 'Certificate',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Text(
            _formatDate(cert['issue_date']),
            style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  static String _formatDate(dynamic date) {
    if (date == null) return 'N/A';
    try {
      return DateFormat('MMM yyyy').format(DateTime.parse(date));
    } catch (e) {
      return 'Invalid';
    }
  }
}

class _OptionTile extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _OptionTile({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? Colors.grey.shade200 : Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? Colors.black87 : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? Colors.black87 : Colors.grey,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? const Icon(Icons.check, color: Colors.black87, size: 16)
                  : null,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? Colors.grey.shade800 : Colors.black87,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
