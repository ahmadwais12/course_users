import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:course_users/components/skeleton_widgets.dart';
import 'package:course_users/providers/student_providers.dart';
import 'package:intl/intl.dart';

class AssignmentsScreenRealtime extends ConsumerStatefulWidget {
  const AssignmentsScreenRealtime({super.key});

  @override
  ConsumerState<AssignmentsScreenRealtime> createState() =>
      _AssignmentsScreenRealtimeState();
}

class _AssignmentsScreenRealtimeState
    extends ConsumerState<AssignmentsScreenRealtime> {
  String searchQuery = '';
  String filterStatus = 'All';
  String filterPriority = 'All';

  @override
  Widget build(BuildContext context) {
    final assignmentsAsync = ref.watch(assignmentsStreamProvider);
    final theme = Theme.of(context);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Enhanced App Bar with Stats
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Assignments',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.purple.shade700,
                      Colors.purple.shade400,
                    ],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: assignmentsAsync.when(
                        data: (assignments) {
                          final pending = assignments
                              .where((a) =>
                                  a['status']?.toString().toLowerCase() ==
                                  'pending')
                              .length;
                          final submitted = assignments
                              .where((a) =>
                                  a['status']?.toString().toLowerCase() ==
                                  'submitted')
                              .length;
                          final graded = assignments
                              .where((a) =>
                                  a['status']?.toString().toLowerCase() ==
                                  'graded')
                              .length;

                          return Row(
                            children: [
                              Expanded(
                                child: _MiniStatCard(
                                  icon: Icons.schedule_rounded,
                                  label: 'Pending',
                                  value: pending.toString(),
                                  color: Colors.orange,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _MiniStatCard(
                                  icon: Icons.done_all_rounded,
                                  label: 'Submitted',
                                  value: submitted.toString(),
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _MiniStatCard(
                                  icon: Icons.grade_rounded,
                                  label: 'Graded',
                                  value: graded.toString(),
                                  color: Colors.black87,
                                ),
                              ),
                            ],
                          );
                        },
                        loading: () => const Row(
                          children: [
                            Expanded(child: SkeletonLine(height: 32)),
                            SizedBox(width: 12),
                            Expanded(child: SkeletonLine(height: 32)),
                            SizedBox(width: 12),
                            Expanded(child: SkeletonLine(height: 32)),
                          ],
                        ),
                        error: (_, __) => const SizedBox.shrink(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Search and Filters
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    decoration: InputDecoration(
                      hintText: 'Search assignments...',
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        color: theme.colorScheme.primary,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      filled: true,
                      fillColor: theme.colorScheme.surfaceContainerHighest,
                    ),
                    onChanged: (value) => setState(() => searchQuery = value),
                  ),
                  const SizedBox(height: 12),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        'All',
                        'Pending',
                        'Submitted',
                        'Graded',
                        'Late'
                      ]
                          .map((status) => Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: FilterChip(
                                  label: Text(status),
                                  selected: filterStatus == status,
                                  onSelected: (selected) =>
                                      setState(() => filterStatus = status),
                                  backgroundColor:
                                      theme.colorScheme.surfaceContainerHighest,
                                  selectedColor:
                                      theme.colorScheme.primaryContainer,
                                  checkmarkColor: theme.colorScheme.primary,
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Assignments List
          assignmentsAsync.when(
            data: (assignments) {
              var filtered = assignments.where((a) {
                final title = a['title']?.toString().toLowerCase() ?? '';
                final subject = a['subject']?.toString().toLowerCase() ?? '';
                final status = a['status']?.toString() ?? 'Pending';
                final matchesSearch =
                    title.contains(searchQuery.toLowerCase()) ||
                        subject.contains(searchQuery.toLowerCase());
                final matchesFilter =
                    filterStatus == 'All' || status == filterStatus;
                return matchesSearch && matchesFilter;
              }).toList();

              // Sort by due date
              filtered.sort((a, b) {
                final dateA = DateTime.tryParse(a['due_date'] ?? '') ??
                    DateTime.now().add(const Duration(days: 365));
                final dateB = DateTime.tryParse(b['due_date'] ?? '') ??
                    DateTime.now().add(const Duration(days: 365));
                return dateA.compareTo(dateB);
              });

              if (filtered.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.assignment_turned_in_rounded,
                          size: 80,
                          color: theme.colorScheme.outline.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No assignments found',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.outline,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          filterStatus == 'All'
                              ? 'All caught up!'
                              : 'Try adjusting your filters',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.outline.withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final assignment = filtered[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: FadeSlideAnimation(
                          delay: Duration(milliseconds: index * 50),
                          child: _AssignmentCard(assignment: assignment),
                        ),
                      );
                    },
                    childCount: filtered.length,
                  ),
                ),
              );
            },
            loading: () => const SliverFillRemaining(
              child: SkeletonDashboard(),
            ),
            error: (error, stack) => SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.error_outline_rounded,
                      size: 64,
                      color: theme.colorScheme.error,
                    ),
                    const SizedBox(height: 16),
                    Text('Error loading assignments'),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: () =>
                          ref.invalidate(assignmentsStreamProvider),
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AssignmentCard extends StatelessWidget {
  final Map<String, dynamic> assignment;

  const _AssignmentCard({required this.assignment});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final status = assignment['status']?.toString() ?? 'Pending';
    final dueDate = DateTime.tryParse(assignment['due_date'] ?? '');
    final isOverdue = dueDate != null && dueDate.isBefore(DateTime.now());
    final daysUntilDue =
        dueDate?.difference(DateTime.now()).inDays;

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: () => _showDetails(context),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with Status
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _getStatusColor(status).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _getStatusIcon(status),
                      color: _getStatusColor(status),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          assignment['title']?.toString() ?? 'Untitled',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          '${assignment['subject'] ?? ''} • ${assignment['class'] ?? ''}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.outline,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: isOverdue
                          ? Colors.red.withValues(alpha: 0.1)
                          : _getStatusColor(status).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      isOverdue ? 'Overdue' : status,
                      style: TextStyle(
                        color: isOverdue ? Colors.red : _getStatusColor(status),
                        fontWeight: FontWeight.bold,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),
              const Divider(height: 1),
              const SizedBox(height: 12),

              // Footer with Due Date and Actions
              Row(
                children: [
                  Icon(
                    Icons.calendar_today_rounded,
                    size: 16,
                    color: isOverdue ? Colors.red : theme.colorScheme.outline,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    isOverdue
                        ? 'Overdue by ${daysUntilDue!.abs()} days'
                        : daysUntilDue != null
                            ? daysUntilDue == 0
                                ? 'Due Today'
                                : daysUntilDue == 1
                                    ? 'Due Tomorrow'
                                    : 'Due in $daysUntilDue days'
                            : 'No due date',
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: isOverdue ? Colors.red : theme.colorScheme.outline,
                      fontWeight: isOverdue ? FontWeight.bold : null,
                    ),
                  ),
                  const Spacer(),
                  Icon(
                    Icons.chevron_right_rounded,
                    color: theme.colorScheme.outline,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return Colors.orange;
      case 'submitted':
        return Colors.black87;
      case 'graded':
        return Colors.black87;
      case 'late':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return Icons.schedule_rounded;
      case 'submitted':
        return Icons.upload_file_rounded;
      case 'graded':
        return Icons.grade_rounded;
      case 'late':
        return Icons.warning_rounded;
      default:
        return Icons.help_outline_rounded;
    }
  }

  void _showDetails(BuildContext context) {
    final theme = Theme.of(context);
    final dueDate = DateTime.tryParse(assignment['due_date'] ?? '');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.85,
        builder: (context, scrollController) => Container(
          padding: const EdgeInsets.all(24),
          child: SingleChildScrollView(
            controller: scrollController,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _getStatusColor(
                                assignment['status']?.toString() ?? 'Pending')
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(
                        _getStatusIcon(
                            assignment['status']?.toString() ?? 'Pending'),
                        color: _getStatusColor(
                            assignment['status']?.toString() ?? 'Pending'),
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        assignment['title']?.toString() ?? 'Untitled',
                        style: theme.textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Details
                _DetailRow(
                  icon: Icons.subject_rounded,
                  label: 'Subject',
                  value: assignment['subject']?.toString() ?? 'N/A',
                ),
                _DetailRow(
                  icon: Icons.class_rounded,
                  label: 'Class',
                  value: assignment['class']?.toString() ?? 'N/A',
                ),
                _DetailRow(
                  icon: Icons.calendar_today_rounded,
                  label: 'Due Date',
                  value: dueDate != null
                      ? DateFormat('MMM dd, yyyy').format(dueDate)
                      : 'Not set',
                ),
                _DetailRow(
                  icon: Icons.info_outline_rounded,
                  label: 'Status',
                  value: assignment['status']?.toString() ?? 'Pending',
                ),
                if (assignment['description'] != null) ...[
                  const SizedBox(height: 16),
                  Text(
                    'Description',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    assignment['description'],
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
                const SizedBox(height: 24),

                // Action Button
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Submit assignment feature'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.upload_file_rounded),
                    label: const Text('Submit Assignment'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.primary),
          const SizedBox(width: 12),
          Text(
            '$label:',
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: theme.textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniStatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _MiniStatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(height: 4),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: Colors.white.withValues(alpha: 0.8),
            ),
          ),
        ],
      ),
    );
  }
}

class FadeSlideAnimation extends StatelessWidget {
  final Widget child;
  final Duration delay;

  const FadeSlideAnimation({
    required this.child,
    this.delay = Duration.zero,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }
}
