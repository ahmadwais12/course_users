import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:course_users/widgets/paginated_list_view.dart';
import 'package:course_users/providers/student_providers.dart';

class GradesScreenRealtime extends ConsumerStatefulWidget {
  const GradesScreenRealtime({super.key});

  @override
  ConsumerState<GradesScreenRealtime> createState() =>
      _GradesScreenRealtimeState();
}

class _GradesScreenRealtimeState extends ConsumerState<GradesScreenRealtime> {
  String searchQuery = '';
  String? selectedTerm;

  @override
  Widget build(BuildContext context) {
    final gradesAsync = ref.watch(gradesStreamProvider);

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search grades...',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              onChanged: (value) => setState(() => searchQuery = value),
            ),
          ),
          Expanded(
            child: gradesAsync.when(
              data: (grades) {
                var filtered = grades.where((g) {
                  final subject = g['subject']?.toString().toLowerCase() ?? '';
                  final exam = g['exam_name']?.toString().toLowerCase() ?? '';
                  final matchesSearch =
                      subject.contains(searchQuery.toLowerCase()) ||
                          exam.contains(searchQuery.toLowerCase());
                  final matchesTerm =
                      selectedTerm == null || g['term'] == selectedTerm;
                  return matchesSearch && matchesTerm;
                }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.grade_outlined,
                            size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        Text('No grades found',
                            style: TextStyle(
                                fontSize: 18, color: Colors.grey[600])),
                      ],
                    ),
                  );
                }

                // Calculate GPA
                final totalPercentage = filtered.fold<double>(
                    0.0, (sum, g) => sum + (g['percentage'] ?? 0.0));
                final avgPercentage = filtered.isNotEmpty
                    ? totalPercentage / filtered.length
                    : 0.0;
                final gpa = (avgPercentage / 25).clamp(0.0, 4.0);

                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(
                      color: Colors.grey[200],
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              children: [
                                Text('GPA',
                                    style: TextStyle(
                                        color: Colors.grey[600], fontSize: 14)),
                                Text(gpa.toStringAsFixed(2),
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(
                                          color: Colors.grey[800],
                                          fontWeight: FontWeight.bold,
                                        )),
                              ],
                            ),
                            Column(
                              children: [
                                Text('Average',
                                    style: TextStyle(
                                        color: Colors.grey[600], fontSize: 14)),
                                Text('${avgPercentage.toStringAsFixed(1)}%',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(
                                          color: Colors.grey[800],
                                          fontWeight: FontWeight.bold,
                                        )),
                              ],
                            ),
                            Column(
                              children: [
                                Text('Courses',
                                    style: TextStyle(
                                        color: Colors.grey[600], fontSize: 14)),
                                Text('${filtered.length}',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(
                                          color: Colors.grey[800],
                                          fontWeight: FontWeight.bold,
                                        )),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ...filtered
                        .map((grade) => Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor:
                                      _getGradeColor(grade['grade'])
                                          .withValues(alpha: 0.1),
                                  child: Text(
                                    grade['grade']?.toString() ?? 'N/A',
                                    style: TextStyle(
                                      color: _getGradeColor(grade['grade']),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                title: Text(
                                    grade['subject']?.toString() ?? 'Unknown'),
                                subtitle: Text(
                                    '${grade['exam_name']} • ${grade['term']}'),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                        '${grade['score']}/${grade['total_marks']}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold)),
                                    Text('${grade['percentage']}%',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontSize: 12)),
                                  ],
                                ),
                              ),
                            )),
                    ],
                );
              },
              loading: () => const SkeletonListPage(itemCount: 8),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
                    const SizedBox(height: 16),
                    Text('Error: $error'),
                    ElevatedButton.icon(
                      onPressed: () => ref.invalidate(gradesStreamProvider),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getGradeColor(dynamic grade) {
    switch (grade.toString().toUpperCase()) {
      case 'A':
      case 'A+':
        return Colors.black87;
      case 'B':
        return Colors.black87;
      case 'C':
        return Colors.orange;
      case 'D':
      case 'F':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
