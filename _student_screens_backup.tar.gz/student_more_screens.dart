import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:course_users/screens/feature_hub_screen.dart';

class GradesDetailScreen extends StatefulWidget {
  const GradesDetailScreen({super.key});

  @override
  State<GradesDetailScreen> createState() => _GradesDetailScreenState();
}

class _GradesDetailScreenState extends State<GradesDetailScreen> {
  List<String> _highlights = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadHighlights('Grades Detail');
  }

  Future<void> _loadHighlights(String screen) async {
    try {
      final data = await Supabase.instance.client
          .from('feature_highlights')
          .select('text')
          .eq('screen', screen)
          .eq('is_active', true);
      if (mounted) {
        setState(() {
          _highlights = (data as List).map((h) => h['text'] as String).toList();
          _loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) => FeatureHubScreen(
        title: 'Grades Detail',
        subtitle:
            'Review subject-wise performance, assessment breakdowns, and grade trends.',
        icon: Icons.grade_rounded,
        color: Colors.black87,
        highlights: _loaded && _highlights.isNotEmpty
            ? _highlights
            : const [
                'Subject performance summary',
                'Assessment breakdown by category',
                'Recent academic progress overview',
              ],
      );
}

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  List<String> _highlights = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadHighlights('Results');
  }

  Future<void> _loadHighlights(String screen) async {
    try {
      final data = await Supabase.instance.client
          .from('feature_highlights')
          .select('text')
          .eq('screen', screen)
          .eq('is_active', true);
      if (mounted) {
        setState(() {
          _highlights = (data as List).map((h) => h['text'] as String).toList();
          _loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) => FeatureHubScreen(
        title: 'Results',
        subtitle:
            'See final outcomes, term results, and academic standing in one place.',
        icon: Icons.assessment_rounded,
        color: Colors.pink,
        highlights: _loaded && _highlights.isNotEmpty
            ? _highlights
            : const [
                'Term result snapshot',
                'Pass and improvement indicators',
                'Performance summary cards',
              ],
      );
}

class LibraryBooksScreen extends StatefulWidget {
  const LibraryBooksScreen({super.key});

  @override
  State<LibraryBooksScreen> createState() => _LibraryBooksScreenState();
}

class _LibraryBooksScreenState extends State<LibraryBooksScreen> {
  List<String> _highlights = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadHighlights('Library Books');
  }

  Future<void> _loadHighlights(String screen) async {
    try {
      final data = await Supabase.instance.client
          .from('feature_highlights')
          .select('text')
          .eq('screen', screen)
          .eq('is_active', true);
      if (mounted) {
        setState(() {
          _highlights = (data as List).map((h) => h['text'] as String).toList();
          _loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) => FeatureHubScreen(
        title: 'Library Books',
        subtitle:
            'Browse issued books, due dates, and library activity from your student account.',
        icon: Icons.menu_book_rounded,
        color: Colors.brown,
        highlights: _loaded && _highlights.isNotEmpty
            ? _highlights
            : const [
                'Current borrowed books',
                'Return due reminders',
                'Reading and borrowing history',
              ],
      );
}

class TimetableScreen extends StatefulWidget {
  const TimetableScreen({super.key});

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  List<String> _highlights = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadHighlights('Timetable');
  }

  Future<void> _loadHighlights(String screen) async {
    try {
      final data = await Supabase.instance.client
          .from('feature_highlights')
          .select('text')
          .eq('screen', screen)
          .eq('is_active', true);
      if (mounted) {
        setState(() {
          _highlights = (data as List).map((h) => h['text'] as String).toList();
          _loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  @override
  Widget build(BuildContext context) => FeatureHubScreen(
        title: 'Timetable',
        subtitle:
            'Keep track of daily classes, room timing, and schedule flow for the week.',
        icon: Icons.schedule_rounded,
        color: Colors.black87,
        highlights: _loaded && _highlights.isNotEmpty
            ? _highlights
            : const [
                'Weekly class schedule',
                'Period timing overview',
                'Room and session planning',
              ],
      );
}
