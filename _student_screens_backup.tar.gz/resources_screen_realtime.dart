import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:course_users/providers/student_providers.dart';
import 'package:course_users/widgets/paginated_list_view.dart';

class ResourcesScreenRealtime extends ConsumerStatefulWidget {
  const ResourcesScreenRealtime({super.key});

  @override
  ConsumerState<ResourcesScreenRealtime> createState() =>
      _ResourcesScreenRealtimeState();
}

class _ResourcesScreenRealtimeState
    extends ConsumerState<ResourcesScreenRealtime> {
  String searchQuery = '';
  String filterType = 'All';

  @override
  Widget build(BuildContext context) {
    final resourcesAsync = ref.watch(resourcesStreamProvider);

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search resources...',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              onChanged: (value) => setState(() => searchQuery = value),
            ),
          ),
          Expanded(
            child: resourcesAsync.when(
              data: (resourcesList) {
                var filtered = resourcesList.where((r) {
                  final title = r['title']?.toString().toLowerCase() ?? '';
                  final matchesSearch =
                      title.contains(searchQuery.toLowerCase());
                  final matchesFilter =
                      filterType == 'All' || r['type'] == filterType;
                  return matchesSearch && matchesFilter;
                }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.folder_outlined,
                            size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        Text('No resources found',
                            style: TextStyle(
                                fontSize: 18, color: Colors.grey[600])),
                      ],
                    ),
                  );
                }

                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.85,
                  ),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final resource = filtered[index];

                    return Card(
                      child: InkWell(
                        onTap: () => _showDetails(resource),
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 60,
                                height: 60,
                                decoration: BoxDecoration(
                                  color: _getTypeColor(resource['type'])
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  _getTypeIcon(resource['type']),
                                  size: 32,
                                  color: _getTypeColor(resource['type']),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                resource['title']?.toString() ?? 'Untitled',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 14),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                resource['subject']?.toString() ?? '',
                                style: TextStyle(
                                    color: Colors.grey[600], fontSize: 12),
                              ),
                              const Spacer(),
                              Row(
                                children: [
                                  Icon(Icons.download,
                                      size: 14, color: Colors.grey[600]),
                                  const SizedBox(width: 4),
                                  Text('${resource['downloads'] ?? 0}',
                                      style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 12)),
                                  const Spacer(),
                                  Icon(Icons.visibility,
                                      size: 14, color: Colors.grey[600]),
                                  const SizedBox(width: 4),
                                  Text('${resource['views'] ?? 0}',
                                      style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 12)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
              loading: () => const SkeletonGridPage(itemCount: 8),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
                    const SizedBox(height: 16),
                    Text('Error: $error'),
                    ElevatedButton.icon(
                      onPressed: () => ref.invalidate(resourcesStreamProvider),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getTypeColor(dynamic type) {
    switch (type.toString().toLowerCase()) {
      case 'pdf':
        return Colors.red;
      case 'video':
        return Colors.black87;
      case 'image':
        return Colors.black87;
      case 'document':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _getTypeIcon(dynamic type) {
    switch (type.toString().toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'video':
        return Icons.videocam;
      case 'image':
        return Icons.image;
      case 'document':
        return Icons.description;
      default:
        return Icons.insert_drive_file;
    }
  }

  void _showDetails(Map<String, dynamic> resource) {
    showModalBottomSheet(
      context: context,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.5,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _getTypeColor(resource['type']).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _getTypeIcon(resource['type']),
                      size: 32,
                      color: _getTypeColor(resource['type']),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          resource['title']?.toString() ?? 'Untitled',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${resource['subject']} • ${resource['type']}',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 32),
              _buildDetailRow('Uploaded', _formatDate(resource['created_at'])),
              _buildDetailRow(
                  'Size', resource['size']?.toString() ?? 'Unknown'),
              _buildDetailRow('Downloads', '${resource['downloads'] ?? 0}'),
              _buildDetailRow('Views', '${resource['views'] ?? 0}'),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Download resource feature')),
                  );
                },
                icon: const Icon(Icons.download),
                label: const Text('Download'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          SizedBox(
              width: 100,
              child: Text('$label:',
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'Unknown';
    DateTime dt;
    if (date is String) {
      dt = DateTime.parse(date);
    } else if (date is DateTime) {
      dt = date;
    } else {
      return 'Unknown';
    }
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
